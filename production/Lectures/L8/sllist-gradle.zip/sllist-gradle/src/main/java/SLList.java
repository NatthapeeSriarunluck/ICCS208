public class SLList {
    private class IntNode {
        int value; // an int data item
        IntNode next; // ref to the next node

        public IntNode(int val, IntNode r) {
            this.value = val;
            this.next = r;
        }
    }

    private IntNode first;
    private int size;

    public SLList() {
        first = null;
        size = 0;
    }


    public void addFirst(int x) {
        first = new IntNode(x, first);
        size++;
    }

    public int getFirst() {
        if (size == 0) {
            throw new IndexOutOfBoundsException();
        }
        return first.value;
    }

    public int get(int index) {
        if (index >= size) {
            throw new IndexOutOfBoundsException();
        }
        if (index == 0) {
            return first.value;
        }
        IntNode current = first.next;
        int count = 1;
        while (count != index) {
            current = current.next;
            count++;
        }
        return current.value;
    }
}