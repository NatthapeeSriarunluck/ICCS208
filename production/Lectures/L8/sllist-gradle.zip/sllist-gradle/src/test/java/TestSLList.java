import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TestSLList {
    @Test
    public void testgetFirst() {
        SLList testlist = new SLList();
        testlist.addFirst(3);
        testlist.addFirst(2);
        testlist.addFirst(1);
        testlist.addFirst(0);
        assertEquals(0, testlist.getFirst());

        assertThrows(IndexOutOfBoundsException.class, () ->{
            SLList testlist1 = new SLList();
            testlist1.getFirst();
        });
    }

    @Test
    public void testget() {
        SLList testlist = new SLList();
        testlist.addFirst(3);
        testlist.addFirst(2);
        testlist.addFirst(1);
        assertEquals(testlist.get(0), 1);
        assertEquals(testlist.get(1), 2);
        assertEquals(testlist.get(2), 3);

        assertThrows(IndexOutOfBoundsException.class, () ->{
            SLList testlist1 = new SLList();
            testlist1.addFirst(3);
            testlist1.addFirst(2);
            testlist1.addFirst(1);
            testlist1.get(3);
        });
    }



}


